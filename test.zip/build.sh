#!/usr/bin/env bash
docker build -t "coursera_master:dev" .
